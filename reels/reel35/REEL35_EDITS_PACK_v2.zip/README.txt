REEL 35 - "Jensen Huang: 33 saal, 1 hafta" - Edits build pack
1. STORYBOARD.json = exact timeline (scenes, cards, timings, rules, credits)
2. audio/AUDIO_MASTER.wav = the ONLY audio (already mixed + synced). Mute all clips.
3. captions.srt = burned-in captions
4. broll/, photos/, cards/ = media
Export: 1080x1920, 30 fps, H.264 -> REEL35_EDITS.mp4
